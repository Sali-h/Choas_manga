این نسخه فقط HTML/CSS/JavaScript است و برای GitHub Pages ساخته شده.
ساختار:
index.html
chapter1.html
chapter1/page1.jpg
chapter1/page2.jpg
...

برای چپتر جدید، chapter1.html را کپی کن، نامش را chapter2.html بگذار و پوشه chapter2 بساز.
صفحات را با نام page1.jpg، page2.jpg و ... داخل آن قرار بده.
در فایل چپتر مقدار totalPages را برابر تعداد صفحات کن.
