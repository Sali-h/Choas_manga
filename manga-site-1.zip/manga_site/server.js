const express = require("express");
const multer = require("multer");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "change-me";

const DATA = path.join(__dirname, "data", "chapters.json");
const UPLOADS = path.join(__dirname, "uploads");

fs.mkdirSync(UPLOADS, { recursive: true });
if (!fs.existsSync(DATA)) fs.writeFileSync(DATA, "[]");

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/uploads", express.static(UPLOADS));

function readChapters() {
  return JSON.parse(fs.readFileSync(DATA, "utf8"));
}
function saveChapters(chapters) {
  fs.writeFileSync(DATA, JSON.stringify(chapters, null, 2));
}
function auth(req, res, next) {
  const password = req.headers["x-admin-password"];
  if (password !== ADMIN_PASSWORD) return res.status(401).json({ error: "رمز مدیریت اشتباه است." });
  next();
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const chapter = String(req.body.chapter || "1").replace(/[^\w\-آ-ی ]/g, "_").trim() || "1";
    const dir = path.join(UPLOADS, `chapter-${chapter}`);
    fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${Date.now()}-${Math.random().toString(36).slice(2)}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: { files: 80, fileSize: 20 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ok = [".jpg",".jpeg",".png",".webp"].includes(path.extname(file.originalname).toLowerCase());
    cb(ok ? null : new Error("فقط JPG, PNG و WEBP مجاز هستند."), ok);
  }
});

app.get("/api/chapters", (req, res) => {
  res.json(readChapters().sort((a,b) => a.number - b.number));
});

app.post("/api/chapters", auth, upload.array("pages", 80), (req, res) => {
  const number = Number(req.body.chapter);
  const title = req.body.title || `Chapter ${number}`;
  if (!Number.isFinite(number)) return res.status(400).json({ error: "شماره چپتر نامعتبر است." });
  if (!req.files?.length) return res.status(400).json({ error: "حداقل یک صفحه انتخاب کنید." });

  const pages = req.files.map((f, i) => ({
    order: i + 1,
    url: `/uploads/${path.basename(path.dirname(f.path))}/${encodeURIComponent(f.filename)}`
  }));

  const chapters = readChapters().filter(c => c.number !== number);
  chapters.push({ number, title, pages, createdAt: new Date().toISOString() });
  saveChapters(chapters);
  res.json({ ok: true });
});

app.delete("/api/chapters/:number", auth, (req, res) => {
  const number = Number(req.params.number);
  const chapters = readChapters();
  const chapter = chapters.find(c => c.number === number);
  if (!chapter) return res.status(404).json({ error: "چپتر پیدا نشد." });

  for (const p of chapter.pages) {
    try {
      const rel = decodeURIComponent(p.url.replace("/uploads/", ""));
      fs.rmSync(path.join(UPLOADS, rel), { force: true });
    } catch {}
  }
  const dir = path.join(UPLOADS, `chapter-${number}`);
  try { fs.rmSync(dir, { recursive: true, force: true }); } catch {}

  saveChapters(chapters.filter(c => c.number !== number));
  res.json({ ok: true });
});

app.use((err, req, res, next) => {
  res.status(400).json({ error: err.message || "خطا" });
});

app.listen(PORT, () => console.log(`Manga site: http://localhost:${PORT}`));
